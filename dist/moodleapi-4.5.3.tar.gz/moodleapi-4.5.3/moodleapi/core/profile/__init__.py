from .get_profile import MoodleProfile

__all__ = ["MoodleProfile"]
