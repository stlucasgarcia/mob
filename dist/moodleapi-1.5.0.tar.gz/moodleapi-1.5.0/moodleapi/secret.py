DATABASE = {
    'db': 'DiscordDB',
    'user': 'postgres',
    'password': '',
    'host': 'localhost',
    'port': 5432,
}