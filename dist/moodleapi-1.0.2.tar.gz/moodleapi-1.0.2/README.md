# Discord Mack Bot
### Discord Bot using Moodle API to get calendar information
The bot was created to get the calendar from Moodle using its API and sending the information of new events, assignments or live classes
It was coded 100% in python and using the following libraries: Pandas, Discord, Itertools.


## > [Roadmap]
### New Moodle commands and functionalities
### Music feature
### Image feature
### Fun commands


We plan to release all these functionalities and beyond! Thanks for your support!

###### Created by Daniel Kauffmann, Lucas Garcia and Matheus Chang with ❤
