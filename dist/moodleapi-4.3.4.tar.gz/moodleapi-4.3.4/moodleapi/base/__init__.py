from .moodle import BaseMoodle

from .process import BaseProcess

__all__ = [
    "BaseMoodle",
    "BaseProcess",
]
