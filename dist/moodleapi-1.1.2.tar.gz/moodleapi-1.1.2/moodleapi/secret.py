Bot_token = 'NzQ1ODAzOTMxMDk5MzMyNjM4.Xz3GCQ.ioTtyAS96W8plRh1APaMxbeY75c'
bitly_token = ['03674be0199488322caca7c0611b4f5e48808ef9',]

DATABASE = {
    'db': 'DiscordDB',
    'user': 'postgres',
    'password': 'SofiaMendonca14*',
    'host': 'localhost',
    'port': 5432,

}
