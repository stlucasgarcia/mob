"""
DATA PACKAGE RESPONSIBLE TO GET INFORMATION FROM MOODLE PLATFORM AND EXPORT IT
TO THE DATABASE

"""

__all__ = [
    "calendar",
    "course",
    "export",
    "professor",
]
