from moodleapi import Mdl

import time
from moodleapi.core.security import Cryptography, Token


BASEURL = "https://eadmoodle.mackenzie.br/"  # Url for any connection with the server
SERVICE = "webservice/"  # Type of service to connect with API (global)
API = "rest/"  # Rest was added in 2.2 version of Moodle API
CONNECTION = "server.php?"  # Global prefix before any parameter


# Cryptography.generate_key_derivation(
#     b"danielvenna2@gmail.com|lsglucas@icloud.com|somosfodas",
#     "discordbot",
# )

params = {
    "discord_id": 226485287612710913,
    "tia": 32074956,
    "course": "CCP",
    "semester": "02",
    "class": "D",
    "guild_id": 426485287612710913,
}

url = f"{BASEURL}{SERVICE}{API}{CONNECTION}"
token = Cryptography.decrypt(
    b"gAAAAABfvphwnv_S1qvxICbM3NdUwgAtrlXd87O-zJEivh_xtoOEbzyLUP4VTZocCpVVauBhGKtdw"
    b"E6UTxDfzcjOvxBGhtZg0oJgCLL5RrXSNf2XVwAOreriwb0eI195LhAAEfkPhM6O"
)
print(token)
wsfunction = "core_calendar_get_calendar_upcoming_view"
total = []

moodle = Mdl()

# token = "g1ea294bc78904caec8b6bbe23a43448"  # errado

for _ in range(1):
    t1 = time.time()

    moodle(
        token,
        url,
        wsfunction,
    )

    t11 = time.time() - t1
    print(f"INIT {t11}")
    t2 = time.time()

    moodle.get(categoryid=2)

    t22 = time.time() - t1
    print(f"GET {t22}")
    t3 = time.time()

    moodle.export(
        db="moodle_assign",
        course="CCP",
        semester="02",
        clss="D",  # TODO: class substituido para clss
        discord_id=226485287612710913,
        guild_id=748168924465594419,
    )

    t33 = time.time() - t3
    print(f"EXPORT TOTAL {t33}")
    print(f"TOTAL {t11+t22+t33}")
    total.append(t11 + t22 + t33)
    print("\n" * 1)

# print(f"Media: {sum(total)/len(total)}")
