"""
DATA PACKAGE RESPONSABLE TO GENERATE CSV FILES FOR THE BOT
"""

__all__ = [
    'calendar',
    'course',
    'export',
]