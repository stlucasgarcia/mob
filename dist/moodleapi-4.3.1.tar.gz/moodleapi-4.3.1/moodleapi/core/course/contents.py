def contents_information():
    pass
