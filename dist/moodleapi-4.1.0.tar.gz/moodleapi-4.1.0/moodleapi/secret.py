DATABASE = {
    "database": "DiscordDB",
    "user": "postgres",
    "password": "SofiaMendonca14*",
    "host": "localhost",
    "port": 5432,
}
