DATABASE = {
    "database": "DiscordDB",
    "user": "postgres",
    "password": "discordbot",
    "host": "localhost",
    "port": 5432,
}