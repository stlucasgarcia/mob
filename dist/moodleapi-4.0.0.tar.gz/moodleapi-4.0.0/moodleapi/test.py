from moodleapi import Mdl

import time


BASEURL = "https://eadmoodle.mackenzie.br/"  # Url for any connection with the server
SERVICE = "webservice/"  # Type of service to connect with API (global)
API = "rest/"  # Rest was added in 2.2 version of Moodle API
CONNECTION = "server.php?"  # Global prefix before any parameter


url = f"{BASEURL}{SERVICE}{API}{CONNECTION}"
token = "194fd7045c33d80b4b3ab4ddda6fa80d"
wsfunction = (
    "core_calendar_get_calendar_day_view"  # "core_calendar_get_calendar_upcoming_view"
)
total = []

moodle = Mdl()

for _ in range(5):
    t1 = time.time()

    moodle(
        token,
        url,
        wsfunction,
    )

    t11 = time.time() - t1
    print(f"INIT {t11}")
    t2 = time.time()

    moodle.get(year=2020, month=11, day=19)

    t22 = time.time() - t1
    print(f"GET {t22}")
    t3 = time.time()

    moodle.export(
        db="moodle_events",
        course="CCP",
        semester="02",
        clss="D",  # TODO: class substituido para clss
        discord_id=226485287612710913,
        guild_id=748168924465594419,
    )

    t33 = time.time() - t3
    print(f"EXPORT TOTAL {t33}")
    print(f"TOTAL {t11+t22+t33}")
    total.append(t11 + t22 + t33)
    print("\n" * 3)

print(f"Media: {sum(total)/len(total)}")
